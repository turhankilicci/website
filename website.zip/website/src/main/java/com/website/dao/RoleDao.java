package com.website.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.website.model.Roles;

public interface RoleDao extends JpaRepository<Roles, Long> {
}