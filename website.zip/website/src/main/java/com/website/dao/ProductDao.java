package com.website.dao;

import com.website.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductDao  extends JpaRepository<Product, Long> {
    Product findByName(String name);
}
