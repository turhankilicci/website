package com.website.services.impl;

import com.website.dao.ProductDao;
import com.website.model.Product;
import com.website.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductDao productDao;

    public Product findByName(String name) {

        return productDao.findByName(name);
    }

    @Override
    public void addProduct(Product product) {
        productDao.saveAndFlush(product);
    }

    @Override
    public void editProduct(Product product) {
        productDao.saveAndFlush(product);
    }

    @Override
    public void deleteProduct(long id) {
        productDao.delete(productDao.getOne(id));
    }

    @Override
    public List<Product> getAll() {
        return productDao.findAll();
    }
}