package com.website.services;

import com.website.model.Product;

import java.util.List;

public interface ProductService {
    Product findByName(String name);
    void addProduct(Product product);
    void editProduct(Product product);
    void deleteProduct(long id);
    List<Product> getAll();
}
