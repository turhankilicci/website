package com.website.services;

import com.website.model.Order;

import java.util.List;

public interface OrderService {
    void addOrder(Order order);
    void updateOrder(Order order);
    void deleteOrder(Long id);
    Order getById(Long id);
    List<Order> findAll();

}
