package com.website.services;

public interface SecurityService {

    void autoLogin(String username, String password);
}
