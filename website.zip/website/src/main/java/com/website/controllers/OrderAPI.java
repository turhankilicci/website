package com.website.controllers;

import com.website.model.Order;
import com.website.services.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class OrderAPI {

    @Autowired
    private OrderService orderService;

    @RequestMapping(value = "/order",  method = RequestMethod.POST)
    public void order(@RequestBody Order order) {
        orderService.addOrder(order);
    }


    @RequestMapping(value = "/ordersAll",  method = RequestMethod.GET)
    public List<Order> getAllOrders() {
        return orderService.findAll();
    }

}
